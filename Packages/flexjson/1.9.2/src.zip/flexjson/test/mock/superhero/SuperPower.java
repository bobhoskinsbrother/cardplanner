package flexjson.test.mock.superhero;

public interface SuperPower {
}
