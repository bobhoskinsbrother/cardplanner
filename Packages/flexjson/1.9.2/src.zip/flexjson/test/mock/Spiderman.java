package flexjson.test.mock;

/**
 * Created by IntelliJ IDEA.
 * User: charlie
 * Date: Jun 24, 2007
 * Time: 7:08:06 PM
 */
public class Spiderman extends Superhero {

    public boolean spideySense;

    public Spiderman() {
        super("Creates web");
        spideySense = true;
    }
}
