package flexjson.test.mock;

public abstract class Superhero {
    public String superpower;

    public Superhero(String superpower) {
        this.superpower = superpower;
    }
}
