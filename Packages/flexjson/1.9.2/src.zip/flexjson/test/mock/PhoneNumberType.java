package flexjson.test.mock;

public enum PhoneNumberType {
        MOBILE, FAX, WORK, PAGER, HOME
}
